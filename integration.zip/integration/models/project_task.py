from odoo import models, fields, api
from odoo.exceptions import UserError
from datetime import datetime
from pytz import timezone
from bs4 import BeautifulSoup
import datetime
import requests
import json


class ProjectTask(models.Model):
    _inherit = 'project.task'

    # start_time = datetime.datetime.utcnow().isoformat() + 'Z'
    task_clockify_id = fields.Char("Task Clockify ID")
    time_entry_id = fields.Char("Time Clockify ID")

    @api.model_create_multi
    def create(self, values):
        task_records = super(ProjectTask, self).create(values)
        for task_record in task_records:
            self.task_creation(task_record, task_record.project_id, task_record.partner_id, task_record.user_ids)
        return task_records

    def write(self, vals):
        if 'name' or 'user_ids' in vals:
            # self.update_task(vals)
            pass
        return super(ProjectTask, self).write(vals)

    def task_creation(self, task_obj, project_obj, customer_obj, assignee_obj):
        if self.env.user.api_sync:
            assignee_ids = []
            for user in assignee_obj:
                if user.clockify_user_id and user.clockify_user_id not in assignee_ids:
                    assignee_ids.append(str(user.clockify_user_id))
                else:
                    set_ids = user.get_ids(user, user.api_key)
                    user.workspace_id = set_ids[0]
                    user.clockify_user_id = set_ids[1]
                    assignee_ids.append(str(user.clockify_user_id))
            api_key = self.env.user.api_key
            workspace_id = self.env.user.workspace_id
            if api_key:
                if not customer_obj.customer_clockify_id:
                    project_obj.partner_id.customers_creation(customer_obj)
                if not project_obj.project_clockify_id:
                    project = project_obj.add_projects(self.env.user.api_key, self.env.user.clockify_user_id,
                                                       self.env.user.workspace_id, customer_obj.customer_clockify_id,
                                                       project_obj.name)
                    if project:
                        project_obj.project_clockify_id = project.get('id', False)
            if not task_obj.task_clockify_id:
                task_added = self.add_task(task_obj.name, api_key, workspace_id, project_obj.project_clockify_id,
                                           assignee_ids)
                if task_added:
                    task_obj.task_clockify_id = task_added.get('id', False)

                # #create time entry
                # time_created = self.create_time_entry(api_key, workspace_id, project_obj, task_obj)
                # if time_created:
                #     task_obj.time_entry_id = time_created.get('id', False)
                #
                # #get time entry
                # time_entry = self.get_time_entry(api_key, workspace_id, task_obj)



    def add_task(self, task_name, api_key, workspace_id, project_id, assignee_ids):
        url = f"https://api.clockify.me/api/v1/workspaces/{workspace_id}/projects/{project_id}/tasks"

        payload = json.dumps({
            "assigneeIds": assignee_ids,
            "name": task_name,

        })
        headers = {
            'x-api-key': api_key,
            'Content-Type': 'application/json'
        }
        try:
            task_added = requests.request("POST", url, headers=headers, data=payload)
            task_added.raise_for_status()
            task_added = task_added.json()
            return task_added
        except requests.exceptions.RequestException:
            task_added = task_added.json()
            raise UserError(f"Error Code: {task_added.get('code')}\n{task_added.get('message')}")

    def create_time_entry(self, api_key, workspace_id, project_obj, task_obj):
        soup = BeautifulSoup(task_obj.description, 'html.parser')
        task_description = soup.get_text()
        url = f"https://api.clockify.me/api/v1/workspaces/{workspace_id}/time-entries"
        payload = json.dumps({
            "billable": True,
            # "customAttributes": [
            #     {
            #         "name": "string",
            #         "namespace": "string",
            #         "value": "string"
            #     }
            # ],
            # "customFields": [
            #     {
            #         "customFieldId": "string",
            #         "sourceType": "WORKSPACE",
            #         "value": {}
            #     }
            # ],
            "description": task_description,
            # "end": task_obj.date_deadline,
            "projectId": project_obj.project_clockify_id,
            # "start": "2019-08-24T14:15:22Z",
            # "tagIds": [
            #     "string"
            # ],
            "taskId": task_obj.task_clockify_id
        })
        headers = {
            'x-api-key': api_key,
            'Content-Type': 'application/json'
        }
        try:
            time_created = requests.request("POST", url, headers=headers, data=payload)
            time_created.raise_for_status()
            time_created = time_created.json()
            return time_created
        except requests.exceptions.RequestException:
            time_created = time_created.json()
            raise UserError(f"Error Code: {time_created.get('code')}\n{time_created.get('message')}")

    def get_time_entry(self, api_key, workspace_id, task_obj):
        url = f"https://api.clockify.me/api/v1/workspaces/{workspace_id}/time-entries/{task_obj.time_entry_id}"
        payload = ""
        headers = {
            'x-api-key': api_key,
            'Content-Type': 'application/json'
        }
        try:
            time_entry = requests.request("GET", url, headers=headers, data=payload)
            time_entry.raise_for_status()
            time_entry = time_entry.json()
            return time_entry
        except requests.exceptions.RequestException:
            time_entry = time_entry.json()
            raise UserError(f"Error Code: {time_entry.get('code')}\n{time_entry.get('message')}")

    def get_tasks(self, api_key, workspace_id, project_id):

        url = f"https://api.clockify.me/api/v1/workspaces/{workspace_id}/projects/{project_id}/tasks"

        payload = ""
        headers = {
            'x-api-key': api_key,
            'Content-Type': 'application/json'
        }

        tasks_in_project = requests.request("GET", url, headers=headers, data=payload)
        tasks_in_project = tasks_in_project.json()
        return tasks_in_project

    def update_task(self, vals):
        payload_dict = {}
        workspace_id, project_id, task_id = (self.env.user.workspace_id, self.project_id.project_clockify_id,
                                             self.task_clockify_id)
        url = f"https://api.clockify.me/api/v1/workspaces/{workspace_id}/projects/{project_id}/tasks/{task_id}"
        if 'name' in vals:
            payload_dict["name"] = vals["name"]
        if 'user_ids' in vals:
            payload_dict["assigneeIds"] = vals["user_ids"]
        payload = json.dumps(payload_dict)
        headers = {
            'x-api-key': self.env.user.api_key,
            'Content-Type': 'application/json'
        }
        task_updated = requests.request("PUT", url, headers=headers, data=payload)
