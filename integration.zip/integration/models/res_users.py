from odoo import models, fields, api
import requests
import json


class ResUsers(models.Model):
    _inherit = 'res.users'

    api_sync = fields.Boolean(string="Api Sync")
    api_key = fields.Char(string="Api Key")
    workspace_id = fields.Char(string="Workspace ID")
    clockify_user_id = fields.Char(string='User ID')

    @api.model_create_multi
    def create(self, vals):
        users_record = super(ResUsers, self).create(vals)
        for user in users_record:
            api_key = user.api_key
            if user.api_sync:
                set_ids = self.get_ids(user, api_key)
                user.workspace_id = set_ids[0]
                user.clockify_user_id = set_ids[1]
        return users_record

    def write(self, vals):
        record = super(ResUsers, self).write(vals)
        for user in self:
            api_key = user.api_key
            if api_key:
                if 'api_sync' in vals:
                    api_sync = vals['api_sync']
                else:
                    api_sync = user.api_sync
                if api_sync and not user.workspace_id:
                    set_ids = user.get_ids(user, api_key)
                    user.workspace_id = set_ids[0]
                    user.clockify_user_id = set_ids[1]
                if not api_sync and user.workspace_id:
                    user.api_key = False
                    user.workspace_id = False
                    user.clockify_user_id = False
                return record

    def get_ids(self, user, api_key):
        if api_key:
            url = "https://api.clockify.me/api/v1/user"
            payload = ""
            headers = {
                'x-api-key': api_key,
                'Content-Type': 'application/json'
            }
            try:
                user_info = requests.request("GET", url, headers=headers, data=payload)
                user_info.raise_for_status()
                user_info = user_info.json()
                workspace_id = user_info['activeWorkspace']
                user_id = user_info["id"]
                set_ids = [workspace_id, user_id]
                return set_ids
            except requests.exceptions.RequestException:
                workspace_id = False
                user_id = False
                set_ids = [workspace_id, user_id]
                return set_ids
