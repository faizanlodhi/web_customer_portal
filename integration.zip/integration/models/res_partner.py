from odoo import models, fields
from odoo.exceptions import UserError
import requests
import json


class ResPartner(models.Model):
    _inherit = 'res.partner'

    customer_clockify_id = fields.Char("Clockify ID")

    def customers_creation(self, customer_obj):
        api_key = self.env.user.api_key
        workspace_id = self.env.user.workspace_id
        # all_clockify_customers = self.get_customers(api_key, workspace_id)
        if customer_obj.name:
            if not customer_obj.customer_clockify_id:
                customer_added = self.add_customers(api_key, workspace_id, customer_obj)
                if customer_added:
                    customer_obj.customer_clockify_id = customer_added.get('id', False)
        return customer_obj.customer_clockify_id

    def add_customers(self, api_key, workspace_id, customer_obj):
        url = f"https://api.clockify.me/api/v1/workspaces/{workspace_id}/clients"

        payload = json.dumps(
            {
                # "email": customer_obj.email,
                "name": customer_obj.name,
            })
        headers = {
            'x-api-key': api_key,
            'Content-Type': 'application/json'
        }
        try:
            customer_added = requests.request("POST", url, headers=headers, data=payload)
            customer_added.raise_for_status()
            customer_added = customer_added.json()
            return customer_added
        except requests.exceptions.RequestException:
            customer_added = customer_added.json()
            raise UserError(f"Error Code: {customer_added.get('code')}\n{customer_added.get('message')}")

    def get_customer(self, api_key, workspace_id, client_id):
        url = f"https://api.clockify.me/api/v1/workspaces/{workspace_id}/clients/{client_id}"

        payload = ""
        headers = {
            'x-api-key': api_key,
            'Content-Type': 'application/json'
        }
        all_clockify_customers = requests.request("GET", url, headers=headers, data=payload)
        all_clockify_customers = all_clockify_customers.json()
        return all_clockify_customers

    def get_customers(self, api_key, workspace_id):
        url = f"https://api.clockify.me/api/v1/workspaces/{workspace_id}/clients"

        payload = ""
        headers = {
            'x-api-key': api_key,
            'Content-Type': 'application/json'
        }
        all_clockify_customers = requests.request("GET", url, headers=headers, data=payload)
        all_clockify_customers = all_clockify_customers.json()
        return all_clockify_customers
