from odoo import models, fields, api
from odoo.exceptions import UserError
import requests
import json


class ProjectProject(models.Model):
    _inherit = 'project.project'

    project_clockify_id = fields.Char("Project Clockify ID")

    @api.model_create_multi
    def create(self, vals):
        project_records = super(ProjectProject, self).create(vals)
        for project_record in project_records:
            self.projects_creation(project_record, project_record.partner_id)
        return project_records

    def projects_creation(self, project_obj, customer_obj):
        if self.env.user.api_sync:
            if customer_obj.name:
                if not customer_obj.customer_clockify_id:
                    project_obj.partner_id.customers_creation(customer_obj)
                api_key = self.env.user.api_key
                clockify_user_id = self.env.user.clockify_user_id
                workspace_id = self.env.user.workspace_id
                if not project_obj.project_clockify_id:
                    added_project = self.add_projects(api_key, clockify_user_id, workspace_id,
                                                      customer_obj.customer_clockify_id, project_obj.name)
                    if added_project:
                        project_obj.project_clockify_id = added_project.get('id', False)
                return project_obj.project_clockify_id

    def add_projects(self, api_key, clockify_user_id, workspace_id, customer_clockify_id, project_name):
        url = f"https://api.clockify.me/api/v1/workspaces/{workspace_id}/projects"
        payload = json.dumps({
            "billable": True,
            "clientId": customer_clockify_id,
            "memberships": [
                {
                    "membershipStatus": "PENDING",
                    "membershipType": "PROJECT",
                    "userId": clockify_user_id
                }
            ],
            "name": project_name,
            "public": True
        })
        headers = {
            'x-api-key': api_key,
            'Content-Type': 'application/json'
        }
        try:
            added_project = requests.request("POST", url, headers=headers, data=payload)
            added_project.raise_for_status()
            added_project = added_project.json()
            return added_project
        except requests.exceptions.RequestException:
            added_project = added_project.json()
            raise UserError(f"Error Code: {added_project.get('code')}\n{added_project.get('message')}")

    def get_projects(self, api_key, workspace_id):
        url = f"https://api.clockify.me/api/v1/workspaces/{workspace_id}/projects/"

        payload = ""
        headers = {
            'x-api-key': api_key,
            'Content-Type': 'application/json'
        }
        response = requests.request("GET", url, headers=headers, data=payload)
        projects = response.json()
        return projects

    def find_project(self, workspace_id, project_id, user):
        url = f"https://api.clockify.me/api/v1/workspaces/{workspace_id}/projects/{project_id}"

        payload = ""
        headers = {
            'x-api-key': user.api_key,
            'Content-Type': 'application/json'
        }
        response = requests.request("GET", url, headers=headers, data=payload)
        project = response.json()
        return project

    def update_project(self, api_key, project_name, project_id, workspace_id, customer_clockify_id):
        url = f"https://api.clockify.me/api/v1/workspaces/{workspace_id}/projects/{project_id}"

        payload = json.dumps({
            "clientId": customer_clockify_id,
            "name": project_name
        })
        headers = {
            'x-api-key': api_key,
            'Content-Type': 'application/json'
        }

        project_updated = requests.request("PUT", url, headers=headers, data=payload)
        project_updated = project_updated.json()
        return project_updated
