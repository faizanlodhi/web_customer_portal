from . import project_task
# from . import api_config
from . import project_project
from . import res_partner
# from . import res_config_settings
# from . import res_company
from . import res_users
