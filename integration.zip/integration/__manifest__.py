{
    'name': "Clockify Integration",
    'version': '1.0',
    'depends': ['project'],
    'author': "Qasim",
    'description': """Clockify Integration""",
    'category': '',
    'license': 'LGPL-3',
    'description': """This is a module of clockify integration""",
    'data': [
        'views/project_task.xml',
        'views/res_users.xml',
    ],

    'installable': True,
    'auto_install': False,
    'application': True,
}
