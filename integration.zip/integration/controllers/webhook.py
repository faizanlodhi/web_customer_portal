from odoo import http
from odoo.http import request


class ClockifyWebhooks(http.Controller):

    @http.route('/clockify/webhook', type='http', auth='public', methods=['GET'], csrf=False)
    def clockify_webhook_handler(self, **post):
        print(post)
        return
